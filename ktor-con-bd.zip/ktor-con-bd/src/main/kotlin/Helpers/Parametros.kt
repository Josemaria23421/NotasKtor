package Helpers

object Parametros {
    val servidor = "localhost"
    val puerto = 3306

    var bbdd = "db_api_DAM2"
    var usuario = "fernando"
    var passwd = "Chubaca2024"
}