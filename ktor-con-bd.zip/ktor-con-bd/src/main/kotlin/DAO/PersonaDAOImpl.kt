package DAO

import Helpers.Database
import Modelos.Persona
import Modelos.PersonaLogin

class PersonaDAOImpl : PersonaDAO {
    override fun insertar(persona: Persona): Boolean {
        val sql = "INSERT INTO personas (dni, nombre, clave, tfno) VALUES (?, ?, ?, ?)"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            statement.setString(1, persona.dni)
            statement.setString(2, persona.nombre)
            statement.setString(3, persona.clave)
            statement.setString(4, persona.tfno)
            try {
                return statement.executeUpdate() > 0
            } catch (e: Exception) {
                return false
            }

        }
        return false
    }

    override fun obtener(dni: String): Persona? {
        val sql = "SELECT * FROM personas WHERE dni = ?"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            statement.setString(1, dni)
            val resultSet = statement.executeQuery()

            if (resultSet.next()) {
                return Persona(
                    dni = resultSet.getString("dni"),
                    nombre = resultSet.getString("nombre"),
                    clave = resultSet.getString("clave"),
                    tfno = resultSet.getString("tfno")
                )
            }
        }
        return null
    }

    override fun actualizar(dni:String, persona: Persona): Boolean {
        val sql = "UPDATE personas SET nombre = ?, clave = ?, tfno = ? WHERE dni = ?"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            statement.setString(1, persona.nombre)
            statement.setString(2, persona.clave)
            statement.setString(3, persona.tfno)
            statement.setString(4, dni)

            return statement.executeUpdate() > 0
        }
        return false
    }

    override fun eliminar(dni: String): Boolean {
        val sql = "DELETE FROM personas WHERE dni = ?"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            statement.setString(1, dni)

            return statement.executeUpdate() > 0
        }
        return false
    }

    override fun obtenerTodos(): List<Persona> {
        val personas = mutableListOf<Persona>()
        val sql = "SELECT * FROM personas"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            val resultSet = statement.executeQuery()

            while (resultSet.next()) {
                val persona = Persona(
                    dni = resultSet.getString("dni"),
                    nombre = resultSet.getString("nombre"),
                    clave = resultSet.getString("clave"),
                    tfno = resultSet.getString("tfno")
                )
                personas.add(persona)
            }
        }
        return personas
    }

    override fun login(p: PersonaLogin):Persona? {
        val sql = "SELECT * FROM personas WHERE dni = ? AND clave = ?"
        val connection = Database.getConnection()
        connection?.use {
            val statement = it.prepareStatement(sql)
            statement.setString(1, p.dni)
            statement.setString(2, p.clave)
            val resultSet = statement.executeQuery()

            if (resultSet.next()) {
                return Persona(
                    dni = resultSet.getString("dni"),
                    nombre = resultSet.getString("nombre"),
                    clave = resultSet.getString("clave"),
                    tfno = resultSet.getString("tfno")
                )
            }
        }
        return null
    }
}