package Modelos

import kotlinx.serialization.Serializable

@Serializable
data class Persona(val dni:String, val nombre:String, val clave:String, val tfno:String)
