package Modelos

import kotlinx.serialization.Serializable

@Serializable
data class PersonaLogin(val dni:String, val clave:String)
