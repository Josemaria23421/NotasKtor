package com.example.rutas.Admin

import com.example.DAO.Admin.AdminDAOImpl
import io.ktor.http.HttpStatusCode
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.put
import io.ktor.server.routing.route

fun Route.adminRoutes() {
    val adminDAO = AdminDAOImpl()

    route("/admin") {

        put("/asignar/manual/{notaId}/{usuarioId}") {

            val notaId = call.parameters["notaId"]?.toIntOrNull()
            val usuarioId = call.parameters["usuarioId"]?.toIntOrNull()

            if (notaId == null || usuarioId == null) {
                call.respond(HttpStatusCode.BadRequest, "Parámetros inválidos")
                return@put
            }

            val ok = adminDAO.asignarTareaManual(notaId, usuarioId)

            if (ok) {
                call.respond(HttpStatusCode.OK, "Tarea asignada correctamente")
            } else {
                call.respond(HttpStatusCode.BadRequest, "No se pudo asignar la tarea")
            }
        }
        val adminDAO = AdminDAOImpl()

        route("/admin") {

            put("/asignar/manual/{notaId}/{usuarioId}") {

                val notaId = call.parameters["notaId"]?.toIntOrNull()
                val usuarioId = call.parameters["usuarioId"]?.toIntOrNull()

                if (notaId == null || usuarioId == null) {
                    call.respond(HttpStatusCode.BadRequest, "Parámetros inválidos")
                    return@put
                }

                val ok = adminDAO.asignarTareaManual(notaId, usuarioId)

                if (ok) {
                    call.respond(HttpStatusCode.OK, "Tarea asignada correctamente")
                } else {
                    call.respond(HttpStatusCode.BadRequest, "No se pudo asignar la tarea")
                }
            }
        }
        get("/carga") {
            val carga = adminDAO.obtenerCargaTrabajo()
            call.respond(carga)
        }
    }
}